import React from "react";

export const Chapter2 = () =>{
    return (
        <div className="chapter2">
            <h1>Chapter2</h1>
        </div>
    )
}

export const Introduction_to_Android = () =>{
    return (
        <div className="chapter2">
            <h1>Chapter2/intro</h1>
        </div>
    )
}

export const Introduction_to_AndroidStudio = () =>{
    return (
        <div className="chapter2">
            <h1>Chapter2/intro_androidStudio</h1>
        </div>
    )
}
export const Tools_Required = () =>{
    return (
        <div className="chapter2">
            <h1>Chapter2/tools</h1>
        </div>
    )
}





