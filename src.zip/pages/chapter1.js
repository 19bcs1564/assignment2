import React from "react";


export const Chapter1 = () =>{
    return (
        <div className="chapter1">
            <h1>Chapter1</h1>
        </div>
    )
}

export const GettingReady = () =>{
    return (
        <div className="chapter1">
            <h1>Chapter1/getting-ready</h1>
            
        </div>
    )
}

export const Variables = () =>{
    return (
        <div className="chapter1">
            <h1>Chapter1/variables</h1>
        </div>
    )
}
export const Comments = () =>{
    return (
        <div className="chapter1">
            <h1>Chapter1/comments</h1>
        </div>
    )
}





