//import logo from './logo.svg';

import Sidebar from './components/sidebar';
import './App.css';
//import {Router as Router, Switch, Route} from 'react-router-dom';
import { Routes as Switch, Route } from 'react-router-dom';
import { BrowserRouter as Router} from 'react-router-dom';
import {Chapter1, GettingReady, Variables, Comments} from './pages/chapter1';
import { Chapter2, Introduction_to_Android, Introduction_to_AndroidStudio, Tools_Required } from './pages/chapter2';
//import VideoPlayer from './components/videoPlayer';

function App() {
  return (
    
    
    <Router>
      
      <Sidebar />
      
      <Switch>
      <Route path = "/chapter1" element ={<Chapter1 />} />
      <Route path = "/chapter1/getting-ready" element ={<GettingReady />} />
      <Route path = "/chapter1/variables" element ={<Variables />} />
      <Route path = "/chapter1/comments" element ={<Comments />} />

      <Route path = "/chapter2" element ={<Chapter2 />} />
      <Route path = "/chapter2/intro" element ={<Introduction_to_Android />} />
      <Route path = "/chapter2/intro_androidStudio" element ={<Introduction_to_AndroidStudio />} />
      <Route path = "/chapter2/tools" element ={<Tools_Required />} />

      </Switch>
    </Router>
   
      
   
  );
}
export default App;
