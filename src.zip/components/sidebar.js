import React, { useState } from 'react';
import {Link} from 'react-router-dom';
import styled from 'styled-components';
import * as IonIcons from "react-icons/io";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import { SidebarData } from './sidebarData';
import SubMenu from './submenu';
import { IconContext } from 'react-icons';


const Nav = styled.div`
    background: #15171c;
    height: 80px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    scroll-behavior: smooth;

`;

const NavIcon = styled(Link)`
    margin-left: 2rem;
    font-size: 2rem;
    height: 80px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
`;

const SidebarNav = styled.nav`
    background: #15171c;
    width: 250px;
    height: 100vh;
    display: flex;
    justify-content: flex-start;
    position: fixed;
    top: 0%;
    left: ${({ sidebar }) => (sidebar ? '0' : '-100%')};
    transition: 350ms;
    z-index: 10;

`;

const SidebarWrap = styled.div`
width: 100%;
`;
const ScrollBarContainer = styled.div`

    width: 100%;
    height: 500px;
    overflow-y: scroll;
    scrollbar-width: thin;
    scrollbar-color: #888888 #f5f5f5;
    position: relative;
    &::-webkit-scrollbar-track {
        scrollbar-color: #f5f5f5;
    }
    &::-webkit-scrollbar-thumb {
        scrollbar-color: #888888;
        border-radius: 6px;
        border: 3px solid #f5f5f5;
    }
    &::-webkit-scrollbar-thumb:hover{
        scrollbar-color: #555555;
    }
`;

function Sidebar(){
    const [sidebar, setSidebar] = useState(false)
    const showSidebar = () => setSidebar(!sidebar)
    return(
        <>
        <ScrollBarContainer>
        <IconContext.Provider value={{color: '#fff'}}>
        <Nav>
            <NavIcon to = '#'>
                <FaIcons.FaBars onClick={showSidebar} />
            </NavIcon>
        </Nav>
        <SidebarNav sidebar={sidebar}>
            <SidebarWrap>
                <NavIcon to = '#'>
                    <AiIcons.AiOutlineClose onClick={showSidebar} />
                </NavIcon>
                {SidebarData.map((item, index) =>{
                    return <SubMenu item={item} key={index} />
                })}
            </SidebarWrap>
        </SidebarNav>
        </IconContext.Provider>
        </ScrollBarContainer>
        </>
    )
}

export default Sidebar;