import React from "react";
import { DefaultPlayer as Video } from "react-html5video/dist";
import 'react-html5video/dist/styles.css';
import introVideo from './datasample/reading-4953.mp4';
import java from './datasample/java.png';
const VideoPlayer = () =>{
    return (
        <Video autoPlay loop
        poster = {java}
        OnCanPlayThrough={()=>{
            console.log('video play')
        }}
        >
            <source src ={introVideo} type="video/webm" width="300" height="300" controls="controls" autoplay="true"></source>
        </Video>
    )

}
export default VideoPlayer;