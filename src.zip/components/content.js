import React, { Component } from "react";
import { PageHeader } from "react-bootstrap";
import VideoPlayer from "./videoPlayer";

class Content extends Component {
    render() {
        return (
          <div>
            <PageHeader className="title">
              <VideoPlayer /> 
            </PageHeader>
          </div>
        );
      }
    }

export default Content;